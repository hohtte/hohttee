/* =========================
   TEXT CONTENT
========================= */


const introMessage = `UM HAIII so this is like a lil concept on a lil gift im making for you, since i stood you up last night i feel like i should be giving a lil idea? this one is the quicker version and i got it done on another web as you can see! but um I WANNA DO SUM CAUSE I MADE YOU WAIT sorry my love.`;



const letterMessage = `its been a few months and a year since we got to know each others existence in this world, and ever since we got into each others live we've been active members in it. And i would say i loved every second and minute of it.

During the time we were apart i kid you not i genuinely felt my heart drop sometimes and also get a random wave of joy, i would like to believe that's like us being connected or I'm js delusional.

through the spam on 13 months we have went through UPSSS and real downs too but i truly don't regret anything cause everything just feels right with you.

i know we are teenagers and still young but i truly want to see you in every corner of my life present and future.

Im more than sure to say that you are my soulmate and no one can tell me otherwise.

i don't ever think that what we have could ever be replicated nor replaced cause you mean everything to me.

every time i wake up i like thinking about you about us, i love seeing things and getting reminded of you, i love knowing that i am with you, i love spending time with you, i love being in love with you and i can say ive been consistently feeling like this for a year.

i love you natu. ❤️`;



/* =========================
   OPEN GIFT
========================= */


function openGift(){


    document.getElementById("music").play();


    document.getElementById("opening")
    .classList.add("hidden");



    setTimeout(()=>{


        document.getElementById("intro")
        .classList.remove("hidden");


        typeText(
            "introText",
            introMessage,
            25
        );


    },1500);



}





/* =========================
   TYPEWRITER
========================= */


function typeText(id,text,speed){


    let element=document.getElementById(id);

    element.innerHTML="";


    let i=0;


    let typing=setInterval(()=>{


        element.innerHTML += text.charAt(i);


        i++;


        if(i>=text.length){


            clearInterval(typing);


            if(id==="introText"){


                document.getElementById(
                "introContinue"
                ).style.display="inline-block";


            }


        }


    },speed);


}





/* =========================
   SHOW LETTER
========================= */


function showLetter(){


    document.getElementById("intro")
    .classList.add("hidden");



    setTimeout(()=>{


        document.getElementById("letterScene")
        .classList.remove("hidden");


        typeText(
            "letterText",
            letterMessage,
            20
        );


    },1200);



}






/* =========================
   SHOW NOTES
========================= */


function showNotes(){


    document.getElementById("letterScene")
    .classList.add("hidden");



    setTimeout(()=>{


        document.getElementById("notesScene")
        .classList.remove("hidden");


    },1200);



}







/* =========================
   HIDDEN NOTES
========================= */


let foundNotes=0;


const notes={


1:
"um HIII",


2:
"sorry for last night :<",


3:
"THIS WAS THE LAST ONE"


};



function openNote(number){


    document.getElementById("notePopup")
    .innerHTML=notes[number];


    event.target.style.display="none";


    foundNotes++;


    if(foundNotes===3){


        document.getElementById(
        "notesContinue"
        ).style.display="block";


    }


}








/* =========================
   FINAL GIFT
========================= */


function showFinalGift(){


    document.getElementById("notesScene")
    .classList.add("hidden");



    setTimeout(()=>{


        document.getElementById("giftScene")
        .classList.remove("hidden");


    },1200);



}






function openFinalGift(){


    document.getElementById("giftScene")
    .classList.add("hidden");



    setTimeout(()=>{


        document.getElementById("endingScene")
        .classList.remove("hidden");


    },1500);



}







/* =========================
   RESET
========================= */


function resetStory(){


    location.reload();


}







/* =========================
   BACKGROUND STARS
========================= */


function createStars(){


    let star=document.createElement("div");


    star.className="star";


    star.style.left=Math.random()*100+"%";

    star.style.top=Math.random()*100+"%";


    star.style.animationDelay=
    Math.random()*3+"s";



    document.getElementById("stars")
    .appendChild(star);



}



for(let i=0;i<120;i++){

    createStars();

}








/* =========================
   ROSE PETALS
========================= */


function createPetal(){


    let petal=document.createElement("div");


    petal.className="petal";


    petal.innerHTML="🦢";


    petal.style.left=Math.random()*100+"vw";


    petal.style.animationDuration=
    (5+Math.random()*5)+"s";



    document.getElementById("petals")
    .appendChild(petal);



    setTimeout(()=>{

        petal.remove();

    },10000);



}


setInterval(createPetal,800);